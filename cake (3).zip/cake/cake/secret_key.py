# Django secret key
# Do NOT check this into version control.

SECRET_KEY = 'x3cn+n3a#!a;&47b;mzrssd$ep6jkm;sp3exj(smbgy*u_g&a('
