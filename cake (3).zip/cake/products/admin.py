from django.contrib import admin
from products.models import Products
# Register your models here.



class Products_admin(admin.ModelAdmin):
    list_display=('title','desc','prod_image')


admin.site.register(Products,Products_admin)