from django.contrib import admin
from info.models import index_info
# Register your models here.

class Information(admin.ModelAdmin):
    list_display=('title','tag_line')


admin.site.register(index_info,Information)