from django.db import models
from tinymce.models import HTMLField
# Create your models here.

class index_info(models.Model):
    title=models.CharField(max_length=50)
    tag_line=HTMLField()